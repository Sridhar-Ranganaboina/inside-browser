# Security Policy

## Reporting a Vulnerability

Please create a [Github Security Advisory](https://github.com/nanobrowser/nanobrowser/security/advisories/new)
